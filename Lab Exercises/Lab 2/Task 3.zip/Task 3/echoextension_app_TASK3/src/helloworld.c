#include "xil_printf.h"
#include "xil_io.h"

int main(void)
{
    unsigned int count = 0;

    xil_printf("Echo test (uppercase + counter): type a character\r\n");

    while (1) {
        char c = inbyte();
        count++;

        if (c >= 'a' && c <= 'z')
            c = c - 'a' + 'A';   /* convert to uppercase */

        xil_printf("\r\nYou typed: %c  (total characters: %d)\r\n", c, count);
    }

    return 0;
}